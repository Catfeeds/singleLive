-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : jszsxt
-- 
-- Part : #1
-- Date : 2017-10-31 09:29:44
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `zc_collection`
-- -----------------------------
DROP TABLE IF EXISTS `zc_collection`;
CREATE TABLE `zc_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` int(11) NOT NULL COMMENT 'users::id',
  `hotel` int(11) NOT NULL COMMENT 'hotels::id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_collection`
-- -----------------------------
INSERT INTO `zc_collection` VALUES ('1', '19', '2');
INSERT INTO `zc_collection` VALUES ('2', '16', '2');

-- -----------------------------
-- Table structure for `zc_config`
-- -----------------------------
DROP TABLE IF EXISTS `zc_config`;
CREATE TABLE `zc_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `key` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '配置名',
  `value` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '配置值',
  `status` tinyint(1) NOT NULL COMMENT '状态 0:后台配置 hotel::id:酒店配置',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_config`
-- -----------------------------
INSERT INTO `zc_config` VALUES ('19', 'mobile', '15991338080', '0');
INSERT INTO `zc_config` VALUES ('20', 'head', '37', '0');
INSERT INTO `zc_config` VALUES ('18', 'webName', '计时住宿管理系统', '0');
INSERT INTO `zc_config` VALUES ('16', 'hotelName', '计时住宿系统', '2');
INSERT INTO `zc_config` VALUES ('17', 'head', '', '2');
INSERT INTO `zc_config` VALUES ('21', 'UserAgree', '', '0');

-- -----------------------------
-- Table structure for `zc_deduct_record`
-- -----------------------------
DROP TABLE IF EXISTS `zc_deduct_record`;
CREATE TABLE `zc_deduct_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `no` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '编号',
  `hotelName` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '酒店名称',
  `roomName` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '房间类型',
  `realname` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '会员姓名',
  `mobile` varchar(12) COLLATE utf8_bin NOT NULL COMMENT '手机号',
  `deduct` int(11) NOT NULL COMMENT '扣除时间/小时',
  `amount` int(11) NOT NULL COMMENT '扣除总金额',
  `createTime` int(11) NOT NULL COMMENT '扣除日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- -----------------------------
-- Table structure for `zc_drawback`
-- -----------------------------
DROP TABLE IF EXISTS `zc_drawback`;
CREATE TABLE `zc_drawback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) DEFAULT NULL COMMENT '订单id',
  `createTime` int(11) DEFAULT NULL COMMENT '操作时间',
  `money` int(10) DEFAULT NULL COMMENT '退款金额',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_drawback`
-- -----------------------------
INSERT INTO `zc_drawback` VALUES ('1', '30', '1509325243', '0');

-- -----------------------------
-- Table structure for `zc_files`
-- -----------------------------
DROP TABLE IF EXISTS `zc_files`;
CREATE TABLE `zc_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `savepath` text COLLATE utf8_bin NOT NULL COMMENT '保存路径',
  `savename` text COLLATE utf8_bin NOT NULL COMMENT '保存名称',
  `name` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '原始名称',
  `size` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '文件的大小',
  `type` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '文件的MIME类型',
  `ext` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '文件的后缀类型',
  `md5` varchar(32) COLLATE utf8_bin NOT NULL COMMENT 'md5哈希验证',
  `sha1` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'sha1哈希验证',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0正常 1无用',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_files`
-- -----------------------------
INSERT INTO `zc_files` VALUES ('1', '/hands/20170908/', '59b1f3dcad6e0.png', 'TIM图片20170906152108.png', '42873', 'image/png', 'png', '08b67d2e5d8ea497b3586ff284e38def', '9f294a0405b5263cf8b1da5eee1e479081421191', '0');
INSERT INTO `zc_files` VALUES ('2', '/hands/20170908/', '59b1f408369cf.png', 'PC登录logo-200x200.png', '46713', 'image/png', 'png', '3b880d92c6fe17e5cffbd202573d9cdf', '46d7a606a852476346b9935b786ad6ed9f72a795', '0');
INSERT INTO `zc_files` VALUES ('3', '/Uploads/20170908/', '59b2049d8cd3f.jpg', '400-1.jpg', '90986', 'image/jpeg', 'jpg', '5db96b34737c13bc1c07449370b5f939', '89cd8ae0472e9c007621380554fed86a6c37f853', '0');
INSERT INTO `zc_files` VALUES ('4', '/Uploads/20170908/', '59b204ac94d78.jpg', '400-2.jpg', '73570', 'image/jpeg', 'jpg', '312484fe6813864d9dcd5af49e3c4a49', '417deb62cc7c50d1509fa51c9de768989fb1196d', '0');
INSERT INTO `zc_files` VALUES ('5', '/hands/', 'oqOMyt3kAFwUlQ84nV1GS6sD5WsY1504838857.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaELaNjjLkV5C1VuUvzcC3VIECnHqtUQIODy9ht3UrsJdnDNYULpYdTc2iavrPPicIibyg0SsTqD3T01IQ/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('6', '/hands/', 'oqOMyt1ahQChhYclrHW_nV1oROs01504849695.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/bAibDVzZoKFIH6ws3RHRZhVQInA9k93fwIDUHpvibrT6riblAHdpG1ZdZrVGKeX14qFp5BQF843ogDiaoS1xQVS1bg/0', '', 'image/png', 'png', '', '', '0');
INSERT INTO `zc_files` VALUES ('7', '/hands/', 'oqOMytxpE-QAjEOVWfYx4Fzd2rwQ1505288009.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/zWhHb1RIIw9CiaJjKTJZo3sZKanW6MAa6R6VJqL5ibLWwT5LvLrKB2qFR8XnExABS2afbrWX5bZ1KpbzKLe4ProA/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('8', '/hands/', 'oqOMyt_ZQJdB9ISigonKFfb6nvNI1505288011.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/fsqYqkvz2otL3t5UCx9gahxxhbibEJibcba1kcGQE9TPepWS8AGL9oXrNibkJHnbe5wEWAHnS3Kn2dF47u7UvKJaQ/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('9', '/hands/20170913/', '59b8e2ba65fa7.jpg', '计时住宿111.jpg', '2542413', 'image/jpeg', 'jpg', '03631fa6062f7d5bc62b6d873b1f3a9c', 'b9f005bb653878a78598e33b1cf7b98d8c82a8a1', '0');
INSERT INTO `zc_files` VALUES ('10', '/hands/', 'oqOMytzYxQP5dBItpMtVbI8t2PKM1505714929.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJj3N9WvKoQia6IsOfnibibhdXqUSiayMVgwDeWy4Uzs7dco9ZicUdDLic9knNsP1dozlpUpo9LBDTP4ib9g/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('11', '/hands/20170919/', '59c07028c5636.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');
INSERT INTO `zc_files` VALUES ('12', '/Uploads/20170919/', '59c07051e2640.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');
INSERT INTO `zc_files` VALUES ('13', '/Uploads/20170919/', '59c07081c5647.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');
INSERT INTO `zc_files` VALUES ('14', '/Uploads/20170919/', '59c070dccf49d.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');
INSERT INTO `zc_files` VALUES ('15', '/Uploads/20170919/', '59c074b5879c0.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');
INSERT INTO `zc_files` VALUES ('16', '/Uploads/20170919/', '59c074e0a6fff.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');
INSERT INTO `zc_files` VALUES ('17', '/hands/', 'oqOMyt_pVzgsVLy5s31vHEsYxDaE1505804135.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtF2QwIjPkTw8hUkyj9dBiaXzrXEaWRUFRtQFgKItMPVNTrq73CnbiblxoXFCYHB7hJiaOicmg90S0tg/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('18', '/hands/', 'oEpq1wZ77u-BmwY0yYv0fkcnR6i81506478011.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIneib4D8J8whU4t53kNnU316A7eZxvQ4JuuCcBokRfo2topl2a4jPRosSlxoNdDWiaAzicHzrEgAH8A/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('19', '/hands/', 'oEpq1wSfEDGJOhUgGGTskz9i0MEw1506484665.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEK0OBwHfiaSYhGMG3MvS8l1maIncXzhwzPXb9UmibgLaAO3FJv8kNz9BcvCBtoL7rbAibXt9EM6yWOIw/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('20', '/hands/', 'oEpq1wQy1fQV3MdO5-uqS-7-12mc1509556029.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIKE935bl6MtSqf2mpCZqJ8hER8GIQoxibm7yWoquP0btXyVTJECca58a4xWg6NXIXSNgW05U3Cr4g/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('21', '/hands/', 'oEpq1wQy1fQV3MdO5-uqS-7-12mc1509558493.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIKE935bl6MtSqf2mpCZqJ8hER8GIQoxibm7yWoquP0btXyVTJECca58a4xWg6NXIXSNgW05U3Cr4g/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('22', '/hands/', 'oEpq1waJdXeOI8Za05k39IBoUqiE1506581215.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/R6Z7If0k0jauwe0PicKYCyLjfQHbw2fZgepQ4y048YkNkGMnicwlbOPaw0or4SfjcV9Tqib396EpGkhZqichUtQEUA/0', '', 'image/png', 'png', '', '', '0');
INSERT INTO `zc_files` VALUES ('23', '/hands/', 'oEpq1wXf3-1t8pCba1yJdc1Yzb_01506639244.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/UF54qObeWZPcFKHPbYzsmG2ErafTiadJRicO6ABmSOatdR0zfSbWr1rtXVia79OKP65FZ0OyzWHZvrAcMFB9QMPQQ/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('24', '/hands/', 'oEpq1wf9C0jIIKtChHyC6eikw8js1506646759.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/5t3sjGYLI8kY3M4YCUiaiaoz3xBBIJ3vA4f5IFHVnBibXUnAzQBtbAD5BAGfmTANOibPvYVa0vSufPibWicF5E6HOGIA/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('25', '/Uploads/20170929/', '59cd9d50c64fa.jpg', '标准间.jpg', '139647', 'image/jpeg', 'jpg', 'f61c69c11c3970101fd01af0f9f182ac', '8432772ad26c3cf4483fcc22498cfe2af8b05508', '0');
INSERT INTO `zc_files` VALUES ('26', '/Uploads/20170929/', '59cd9dc28c6aa.jpg', '商务间.jpg', '148987', 'image/jpeg', 'jpg', '823027dcab54dc97a9457ee61e160afa', 'faf1ac13cc8b89b9edd20bac67404ecf48009830', '0');
INSERT INTO `zc_files` VALUES ('27', '/Uploads/20170929/', '59cd9ddfaa0f6.jpg', '豪华间.jpg', '149015', 'image/jpeg', 'jpg', 'd4a9f80c1fb8264c17518a13c35b5060', '3538083c8eb09c2d51c83ea4b22e3d006db19129', '0');
INSERT INTO `zc_files` VALUES ('28', '/hands/', 'oEpq1wQy1fQV3MdO5-uqS-7-12mc1506648980.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIKE935bl6MtSqf2mpCZqJ8hER8GIQoxibm7yWoquP0btXyVTJECca58a4xWg6NXIXSNgW05U3Cr4g/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('29', '/hands/', 'oEpq1wbZ91OotnpVy9uCd1ITiqS81506735053.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/dibXSrJBDia2fbTnhxuxsjYjSE19LcorJlmKh9Q6K5bYibGlaVvBdcNtnARlibicoR3QOUnS2DwKEsJupRzb8G7opHA/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('30', '/hands/20171016/', '59e41be648587.png', 'client-2.png', '6351', 'image/png', 'png', 'ec3f9d4e33f9b86255bfec9d17302a93', '0a39425e591ee73dcf74fd1fbaa793388dea2f25', '0');
INSERT INTO `zc_files` VALUES ('31', '/Uploads/20171016/', '59e41c2b1f23c.png', 'work-27.png', '33858', 'image/png', 'png', '72add3a429241b54dc91ecca7b16e5d1', 'd9e3e9eeb06254ab3a2557ea8f6ce8e7b8beebaf', '0');
INSERT INTO `zc_files` VALUES ('32', '/hands/', 'oEpq1wej_QBWUpIyLA0G4BtNZw6k1508143669.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKMofibAtgMA5gZLv4nibbvplslqsLH22KGkeibC0SZkBKTQS6R7CmD9iasR9njF8UwwpjLibLtkmUJHlg/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('33', '/hands/', 'oEpq1wSfEDGJOhUgGGTskz9i0MEw1508147724.jpg', 'http://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEK0OBwHfiaSYhGMG3MvS8l1maIncXzhwzPXb9UmibgLaAO3FJv8kNz9BcvCBtoL7rbAibXt9EM6yWOIw/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('34', '/hands/', 'oEpq1wXRBGWYz7Livij9Gczvh_UI1509151762.jpg', 'http://wx.qlogo.cn/mmhead/BfRL3E0G1pcofWeaSUGHqh1ugN7sI0WP3T5oSc6NptMu0peaHwmibdA/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('35', '/hands/', 'oEpq1waDZWwQqViNXk_76SlYwpZk1509151764.jpg', 'http://wx.qlogo.cn/mmhead/Q3auHgzwzM4alHwJBeSS6IOhmfSEIeYnbCldB6fH4sB5oiaJYGcibrsw/0', '', 'image/jpeg', 'jpeg', '', '', '0');
INSERT INTO `zc_files` VALUES ('36', '/hands/20171030/', '59f67f17927dc.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');
INSERT INTO `zc_files` VALUES ('37', '/hands/20171031/', '59f7bf1167127.jpg', '计时住宿1.jpg', '449817', 'image/jpeg', 'jpg', 'aebfc859d8183de1342c231a8d67b115', '946f202cd74aa2e3d90c386faaac335d429c1e22', '0');

-- -----------------------------
-- Table structure for `zc_hotel_admins`
-- -----------------------------
DROP TABLE IF EXISTS `zc_hotel_admins`;
CREATE TABLE `zc_hotel_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '用户名',
  `nickname` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '昵称',
  `realname` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '真实姓名',
  `mobile` varchar(13) COLLATE utf8_bin NOT NULL COMMENT '联系方式',
  `hotel` int(11) NOT NULL COMMENT 'hotel::id',
  `password` char(32) COLLATE utf8_bin NOT NULL COMMENT '登录密码',
  `root` int(11) NOT NULL COMMENT '0超级管理员 hotel_admins::id子账号',
  `group` int(11) NOT NULL COMMENT '权限',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0正常 1封停 9删除',
  PRIMARY KEY (`id`),
  KEY `hotel` (`hotel`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='酒店管理员';

-- -----------------------------
-- Records of `zc_hotel_admins`
-- -----------------------------
INSERT INTO `zc_hotel_admins` VALUES ('1', 'rjjd', 'rjjd', '', '', '1', '96e79218965eb72c92a549dd5a330112', '0', '0', '0');
INSERT INTO `zc_hotel_admins` VALUES ('2', 'mjjd', 'mjjd', '', '', '2', '86f01f07093435ddeec1dcb0535ff816', '0', '0', '0');
INSERT INTO `zc_hotel_admins` VALUES ('3', 'hotel', 'hotel', '', '', '3', 'e10adc3949ba59abbe56e057f20f883e', '0', '0', '0');

-- -----------------------------
-- Table structure for `zc_hotel_banner`
-- -----------------------------
DROP TABLE IF EXISTS `zc_hotel_banner`;
CREATE TABLE `zc_hotel_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel` int(11) DEFAULT NULL COMMENT '酒店id',
  `imgs` text COLLATE utf8_bin COMMENT '酒店banner的id',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `update_time` int(11) NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='酒店banner表';


-- -----------------------------
-- Table structure for `zc_hotel_rooms`
-- -----------------------------
DROP TABLE IF EXISTS `zc_hotel_rooms`;
CREATE TABLE `zc_hotel_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel` int(11) NOT NULL COMMENT 'hotels::id',
  `room` int(11) NOT NULL COMMENT 'rooms::id',
  `price` int(11) NOT NULL COMMENT '24小时价格',
  `amount` float(10,4) NOT NULL COMMENT '房间按小时,由用户输入的24小时价格计算出来',
  `minimum` int(11) NOT NULL COMMENT '最低入住时长（小时）',
  `minute` int(11) NOT NULL COMMENT '超过分钟数算1小时',
  `createTime` int(11) NOT NULL COMMENT '新增日期',
  `updateTime` int(11) NOT NULL COMMENT '更新日期',
  `imgs_ids` text COLLATE utf8_bin NOT NULL COMMENT '房间图片s',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0正常 1停用 9删除',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_hotel_rooms`
-- -----------------------------
INSERT INTO `zc_hotel_rooms` VALUES ('1', '1', '1', '158', '6.5833', '14', '30', '1504245079', '0', '3', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('2', '1', '2', '388', '16.1667', '15', '30', '1504245106', '0', '4', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('3', '1', '1', '158', '6.5833', '14', '30', '0', '0', '3,3', '0');
INSERT INTO `zc_hotel_rooms` VALUES ('4', '1', '2', '388', '16.1667', '15', '30', '0', '0', '4,4', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('5', '2', '1', '188', '7.8333', '14', '30', '1505783892', '0', '12', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('6', '2', '2', '238', '9.9167', '14', '30', '1505783938', '0', '', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('7', '2', '3', '388', '16.1667', '14', '30', '1505784031', '0', '', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('8', '1', '4', '388', '16.1667', '14', '30', '1505785021', '0', '15', '0');
INSERT INTO `zc_hotel_rooms` VALUES ('9', '2', '4', '278', '11.5833', '14', '30', '1505785057', '0', '16', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('10', '2', '1', '0', '0.0078', '14', '30', '0', '0', '25', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('11', '2', '1', '0', '0.0000', '14', '30', '0', '0', '25', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('12', '2', '1', '0', '0.0078', '14', '30', '0', '0', '25', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('13', '2', '1', '1', '0.0417', '14', '30', '0', '0', '25', '0');
INSERT INTO `zc_hotel_rooms` VALUES ('14', '2', '2', '2', '0.1167', '14', '30', '0', '0', '26', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('15', '2', '3', '3', '0.1250', '14', '30', '0', '0', '27', '0');
INSERT INTO `zc_hotel_rooms` VALUES ('16', '3', '1', '0', '0.0004', '14', '30', '1508121644', '0', '31', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('17', '3', '1', '0', '0.0042', '14', '30', '0', '0', '31', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('18', '2', '2', '0', '0.0042', '14', '30', '0', '0', '26', '9');
INSERT INTO `zc_hotel_rooms` VALUES ('19', '2', '2', '2', '0.0833', '14', '30', '0', '0', '26', '0');

-- -----------------------------
-- Table structure for `zc_hotels`
-- -----------------------------
DROP TABLE IF EXISTS `zc_hotels`;
CREATE TABLE `zc_hotels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotelName` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '酒店名称',
  `province` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '省',
  `city` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '市',
  `area` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '区',
  `mobile` varchar(13) COLLATE utf8_bin NOT NULL COMMENT '联系方式',
  `address` text COLLATE utf8_bin NOT NULL COMMENT '详细地址',
  `head` int(11) NOT NULL COMMENT 'files::id',
  `createTime` int(11) NOT NULL COMMENT '新增日期',
  `updateTime` int(11) NOT NULL COMMENT '更新日期',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0正常 1停用 9删除',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_hotels`
-- -----------------------------
INSERT INTO `zc_hotels` VALUES ('1', '如家酒店', '北京市', '北京市', '东城区', '654321', '1234567', '2', '1504245010', '1504245010', '0');
INSERT INTO `zc_hotels` VALUES ('2', '测试酒店', '陕西省', '安康市', '汉滨区', '15991338080', '滨江大道1号', '11', '1505783850', '1509326351', '0');

-- -----------------------------
-- Table structure for `zc_news`
-- -----------------------------
DROP TABLE IF EXISTS `zc_news`;
CREATE TABLE `zc_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` text COLLATE utf8_bin NOT NULL COMMENT '标题',
  `body` text COLLATE utf8_bin NOT NULL COMMENT '内容',
  `createTime` int(11) NOT NULL COMMENT '发布日期',
  `startTime` int(11) NOT NULL COMMENT '生效日期',
  `endTime` int(11) NOT NULL COMMENT '截止日期',
  `hotel` tinyint(1) NOT NULL COMMENT '酒店端 0:发送 1:不发送',
  `mobile` tinyint(1) NOT NULL COMMENT '用户端 0:发送 1：不发送 2:酒店端点击入住时单个发送',
  `status` tinyint(1) NOT NULL COMMENT '状态 0:等待生效 1:已生效 2:已过期 9:删除',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_news`
-- -----------------------------
INSERT INTO `zc_news` VALUES ('1', '入住提示', '尊敬的用户：joy您于2017-10-16 16:51:56入住测试酒店房间类型为豪华间已经为您计时', '1508143916', '1508143916', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('2', '入住提示', '尊敬的用户：哈哈您于2017-10-16 16:52:01入住测试酒店房间类型为商务间已经为您计时', '1508143921', '1508143921', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('3', '入住提示', '尊敬的用户：哈哈您于2017-10-16 16:52:05入住测试酒店房间类型为标准间已经为您计时', '1508143924', '1508143924', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('4', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145426', '1508145426', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('5', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145426', '1508145426', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('6', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145426', '1508145426', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('7', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145481', '1508145481', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('8', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145481', '1508145481', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('9', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145481', '1508145481', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('10', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145541', '1508145541', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('11', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145541', '1508145541', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('12', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145541', '1508145541', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('13', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145601', '1508145601', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('14', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145601', '1508145601', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('15', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145601', '1508145601', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('16', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145661', '1508145661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('17', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145661', '1508145661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('18', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145661', '1508145661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('19', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145661', '1508145661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('20', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145661', '1508145661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('21', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508145661', '1508145661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('22', '入住提示', '尊敬的用户：李煦您于2017-10-17 10:38:45入住测试酒店房间类型为商务间已经为您计时', '1508207925', '1508207925', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('23', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226481', '1508226481', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('24', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226481', '1508226481', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('25', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226481', '1508226481', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('26', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226661', '1508226661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('27', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226661', '1508226661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('28', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226661', '1508226661', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('29', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226841', '1508226841', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('30', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226841', '1508226841', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('31', '温馨提示', '尊敬的用户joy您所入住的测试酒店房间类型为豪华间订单号为A211508143879离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508226841', '1508226841', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('32', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为标准间订单号为A191508143584离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508227021', '1508227021', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('33', '温馨提示', '尊敬的用户哈哈您所入住的测试酒店房间类型为商务间订单号为A191508143590离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508227021', '1508227021', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('34', '退房提示', '尊敬的用户：joy您于2017-10-17 16:45:06在测试酒店退房,入住时长为24小时,期待您的下次光临！', '1508229906', '1508229906', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('35', '退房提示', '尊敬的用户：哈哈您于2017-10-17 17:34:35在测试酒店退房,入住时长为25小时,期待您的下次光临！', '1508232875', '1508232875', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('36', '退房提示', '尊敬的用户：哈哈您于2017-10-17 17:34:40在测试酒店退房,入住时长为25小时,期待您的下次光临！', '1508232880', '1508232880', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('37', '温馨提示', '尊敬的用户李煦您所入住的测试酒店房间类型为商务间订单号为A171508207891离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508290562', '1508290562', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('38', '温馨提示', '尊敬的用户李煦您所入住的测试酒店房间类型为商务间订单号为A171508207891离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508290742', '1508290742', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('39', '温馨提示', '尊敬的用户李煦您所入住的测试酒店房间类型为商务间订单号为A171508207891离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1508290922', '1508290922', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('40', '退房提示', '尊敬的用户：李煦您于2017-10-20 16:02:17在测试酒店退房,入住时长为77小时,期待您的下次光临！', '1508486537', '1508486537', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('41', '入住提示', '尊敬的用户：胡堂松您于2017-10-28 08:58:03入住测试酒店房间类型为豪华间已经为您计时', '1509152283', '1509152283', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('42', '入住提示', '尊敬的用户：景小兵您于2017-10-28 08:58:21入住测试酒店房间类型为标准间已经为您计时', '1509152301', '1509152301', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('43', '入住提示', '尊敬的用户：陶友洁您于2017-10-28 08:58:43入住测试酒店房间类型为豪华间已经为您计时', '1509152323', '1509152323', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('44', '入住提示', '尊敬的用户：陶友洁您于2017-10-28 08:58:48入住测试酒店房间类型为标准间已经为您计时', '1509152328', '1509152328', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('45', '续时提示', '尊敬的用户：胡堂松您于2017-10-28 09:02:04为测试酒店房间类型为豪华间续时24小时，之前剩余72小时,总剩余96小时', '1509152524', '1509152524', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('46', '退房提示', '尊敬的用户：景小兵您于2017-10-28 09:06:05在测试酒店退房,入住时长为14小时,期待您的下次光临！', '1509152765', '1509152765', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('47', '入住提示', '尊敬的用户：景小兵您于2017-10-28 09:14:18入住测试酒店房间类型为标准间已经为您计时', '1509153258', '1509153258', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('48', '续时提示', '尊敬的用户：陶友洁您于2017-10-28 22:41:25为测试酒店房间类型为标准间续时24小时，之前剩余24小时,总剩余48小时', '1509201685', '1509201685', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('49', '温馨提示', '尊敬的用户景小兵您所入住的测试酒店房间类型为标准间订单号为A241509153241离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509271921', '1509271921', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('50', '温馨提示', '尊敬的用户景小兵您所入住的测试酒店房间类型为标准间订单号为A241509153241离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509272101', '1509272101', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('51', '温馨提示', '尊敬的用户景小兵您所入住的测试酒店房间类型为标准间订单号为A241509153241离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509272281', '1509272281', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('52', '续时提示', '尊敬的用户：景小兵您于2017-10-29 21:19:56为测试酒店房间类型为标准间续时24小时，之前剩余34小时,总剩余58小时', '1509283196', '1509283196', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('53', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为标准间订单号为A231509152282离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509321241', '1509321241', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('54', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为标准间订单号为A231509152282离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509321422', '1509321422', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('55', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为标准间订单号为A231509152282离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509321602', '1509321602', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('56', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为标准间订单号为A231509152282离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509321782', '1509321782', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('57', '退房提示', '尊敬的用户：陶友洁您于2017-10-30 08:43:37在测试酒店退房,入住时长为48小时,期待您的下次光临！', '1509324217', '1509324217', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('58', '温馨提示', '尊敬的用户景小兵您所入住的测试酒店房间类型为标准间订单号为A241509153241离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509358321', '1509358321', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('59', '温馨提示', '尊敬的用户景小兵您所入住的测试酒店房间类型为标准间订单号为A241509153241离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509358501', '1509358501', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('60', '温馨提示', '尊敬的用户景小兵您所入住的测试酒店房间类型为标准间订单号为A241509153241离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509358681', '1509358681', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('61', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为豪华间订单号为A231509152273离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509407641', '1509407641', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('62', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为豪华间订单号为A231509152273离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509407821', '1509407821', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('63', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为豪华间订单号为A231509152273离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509408002', '1509408002', '0', '1', '2', '1');
INSERT INTO `zc_news` VALUES ('64', '温馨提示', '尊敬的用户陶友洁您所入住的测试酒店房间类型为豪华间订单号为A231509152273离入住到期时间还有1小时请您及时收拾好东西,联系酒店前台方便您办理退房', '1509408182', '1509408182', '0', '1', '2', '1');

-- -----------------------------
-- Table structure for `zc_news_hotel`
-- -----------------------------
DROP TABLE IF EXISTS `zc_news_hotel`;
CREATE TABLE `zc_news_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `news` int(11) NOT NULL COMMENT 'news::id',
  `hotel` int(11) NOT NULL COMMENT 'hotels::id',
  `status` tinyint(1) NOT NULL COMMENT '状态 0:未读 1:已读 9:删除',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- -----------------------------
-- Table structure for `zc_news_user`
-- -----------------------------
DROP TABLE IF EXISTS `zc_news_user`;
CREATE TABLE `zc_news_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `news` int(11) NOT NULL COMMENT 'news::id',
  `users` int(11) NOT NULL COMMENT 'users::id',
  `status` tinyint(1) NOT NULL COMMENT '状态 0:未读 1:已读 9:删除',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_news_user`
-- -----------------------------
INSERT INTO `zc_news_user` VALUES ('1', '1', '21', '1');
INSERT INTO `zc_news_user` VALUES ('2', '2', '19', '1');
INSERT INTO `zc_news_user` VALUES ('3', '3', '19', '1');
INSERT INTO `zc_news_user` VALUES ('4', '4', '19', '1');
INSERT INTO `zc_news_user` VALUES ('5', '5', '19', '1');
INSERT INTO `zc_news_user` VALUES ('6', '6', '21', '1');
INSERT INTO `zc_news_user` VALUES ('7', '7', '19', '1');
INSERT INTO `zc_news_user` VALUES ('8', '8', '19', '1');
INSERT INTO `zc_news_user` VALUES ('9', '9', '21', '1');
INSERT INTO `zc_news_user` VALUES ('10', '10', '19', '1');
INSERT INTO `zc_news_user` VALUES ('11', '11', '19', '1');
INSERT INTO `zc_news_user` VALUES ('12', '12', '21', '1');
INSERT INTO `zc_news_user` VALUES ('13', '13', '19', '1');
INSERT INTO `zc_news_user` VALUES ('14', '14', '19', '1');
INSERT INTO `zc_news_user` VALUES ('15', '15', '21', '1');
INSERT INTO `zc_news_user` VALUES ('16', '16', '19', '1');
INSERT INTO `zc_news_user` VALUES ('17', '17', '19', '1');
INSERT INTO `zc_news_user` VALUES ('18', '18', '21', '1');
INSERT INTO `zc_news_user` VALUES ('19', '19', '19', '1');
INSERT INTO `zc_news_user` VALUES ('20', '20', '19', '1');
INSERT INTO `zc_news_user` VALUES ('21', '21', '21', '1');
INSERT INTO `zc_news_user` VALUES ('22', '22', '17', '1');
INSERT INTO `zc_news_user` VALUES ('23', '23', '19', '1');
INSERT INTO `zc_news_user` VALUES ('24', '24', '19', '1');
INSERT INTO `zc_news_user` VALUES ('25', '25', '21', '1');
INSERT INTO `zc_news_user` VALUES ('26', '26', '19', '1');
INSERT INTO `zc_news_user` VALUES ('27', '27', '19', '1');
INSERT INTO `zc_news_user` VALUES ('28', '28', '21', '1');
INSERT INTO `zc_news_user` VALUES ('29', '29', '19', '1');
INSERT INTO `zc_news_user` VALUES ('30', '30', '19', '1');
INSERT INTO `zc_news_user` VALUES ('31', '31', '21', '1');
INSERT INTO `zc_news_user` VALUES ('32', '32', '19', '1');
INSERT INTO `zc_news_user` VALUES ('33', '33', '19', '1');
INSERT INTO `zc_news_user` VALUES ('34', '34', '21', '1');
INSERT INTO `zc_news_user` VALUES ('35', '35', '19', '0');
INSERT INTO `zc_news_user` VALUES ('36', '36', '19', '1');
INSERT INTO `zc_news_user` VALUES ('37', '37', '17', '1');
INSERT INTO `zc_news_user` VALUES ('38', '38', '17', '1');
INSERT INTO `zc_news_user` VALUES ('39', '39', '17', '1');
INSERT INTO `zc_news_user` VALUES ('40', '40', '17', '1');
INSERT INTO `zc_news_user` VALUES ('41', '41', '18', '1');
INSERT INTO `zc_news_user` VALUES ('42', '42', '24', '1');
INSERT INTO `zc_news_user` VALUES ('43', '43', '23', '1');
INSERT INTO `zc_news_user` VALUES ('44', '44', '23', '1');
INSERT INTO `zc_news_user` VALUES ('45', '45', '18', '1');
INSERT INTO `zc_news_user` VALUES ('46', '46', '24', '1');
INSERT INTO `zc_news_user` VALUES ('47', '47', '24', '1');
INSERT INTO `zc_news_user` VALUES ('48', '48', '23', '1');
INSERT INTO `zc_news_user` VALUES ('49', '49', '24', '1');
INSERT INTO `zc_news_user` VALUES ('50', '50', '24', '1');
INSERT INTO `zc_news_user` VALUES ('51', '51', '24', '1');
INSERT INTO `zc_news_user` VALUES ('52', '52', '24', '1');
INSERT INTO `zc_news_user` VALUES ('53', '53', '23', '1');
INSERT INTO `zc_news_user` VALUES ('54', '54', '23', '1');
INSERT INTO `zc_news_user` VALUES ('55', '55', '23', '0');
INSERT INTO `zc_news_user` VALUES ('56', '56', '23', '0');
INSERT INTO `zc_news_user` VALUES ('57', '57', '23', '0');
INSERT INTO `zc_news_user` VALUES ('58', '58', '24', '0');
INSERT INTO `zc_news_user` VALUES ('59', '59', '24', '0');
INSERT INTO `zc_news_user` VALUES ('60', '60', '24', '0');
INSERT INTO `zc_news_user` VALUES ('61', '61', '23', '0');
INSERT INTO `zc_news_user` VALUES ('62', '62', '23', '1');
INSERT INTO `zc_news_user` VALUES ('63', '63', '23', '1');
INSERT INTO `zc_news_user` VALUES ('64', '64', '23', '1');

-- -----------------------------
-- Table structure for `zc_order`
-- -----------------------------
DROP TABLE IF EXISTS `zc_order`;
CREATE TABLE `zc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `no` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '订单号',
  `userId` int(11) NOT NULL COMMENT 'users::id',
  `hotel` int(11) NOT NULL COMMENT 'hotels::id',
  `room` int(11) NOT NULL COMMENT 'hotel_room::id',
  `duration` int(11) NOT NULL COMMENT '购买时长/小时',
  `used` int(11) NOT NULL COMMENT '已用时长/小时',
  `amount` float(10,4) NOT NULL COMMENT '购买单价 元/小时',
  `all_amount` int(11) NOT NULL COMMENT '订单累计总价格',
  `status` tinyint(2) NOT NULL COMMENT '状态 9已删除 8待付款 1已完成 0可用 2入住中 3已退款 7-退款申请',
  `postal` tinyint(2) NOT NULL COMMENT '状态 0:未提现 1:已提现',
  `createTime` int(11) NOT NULL,
  `updateTime` int(11) NOT NULL,
  `checkIn` tinyint(2) NOT NULL COMMENT '状态 0:未入住过 1:已入住过',
  `payfields` text COLLATE utf8_bin NOT NULL COMMENT '支付条件预存字段',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`userId`,`no`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_order`
-- -----------------------------
INSERT INTO `zc_order` VALUES ('1', 'H191508143439', '19', '2', '13', '24', '25', '0.0417', '0', '1', '0', '1508143439', '1508143924', '1', '');
INSERT INTO `zc_order` VALUES ('2', 'H191508143439', '19', '2', '14', '24', '25', '0.1167', '0', '1', '0', '1508143439', '1508143921', '1', '');
INSERT INTO `zc_order` VALUES ('3', 'H211508143858', '21', '2', '15', '24', '24', '0.1250', '0', '1', '0', '1508143858', '1508143916', '1', '');
INSERT INTO `zc_order` VALUES ('4', 'H211508147725', '21', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1508147725', '1508147725', '0', '');
INSERT INTO `zc_order` VALUES ('5', 'H211508203171', '21', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1508203171', '1508203171', '0', '');
INSERT INTO `zc_order` VALUES ('6', 'H121508203177', '12', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508203177', '1508203177', '0', '');
INSERT INTO `zc_order` VALUES ('7', 'H211508203220', '21', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1508203220', '1508203220', '0', '');
INSERT INTO `zc_order` VALUES ('8', 'H121508203229', '12', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508203229', '1508203229', '0', '');
INSERT INTO `zc_order` VALUES ('9', 'H211508203995', '21', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1508203995', '1508203995', '0', '');
INSERT INTO `zc_order` VALUES ('10', 'H191508203998', '19', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508203998', '1508203998', '0', '');
INSERT INTO `zc_order` VALUES ('11', 'H121508204009', '12', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508204009', '1508204009', '0', '');
INSERT INTO `zc_order` VALUES ('12', 'H161508207276', '16', '2', '13', '24', '0', '0.0417', '1', '0', '0', '1508207276', '1508207291', '0', '');
INSERT INTO `zc_order` VALUES ('13', 'H121508207374', '12', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508207374', '1508207374', '0', '');
INSERT INTO `zc_order` VALUES ('14', 'H121508207458', '12', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508207458', '1508207458', '0', '');
INSERT INTO `zc_order` VALUES ('15', 'H121508207496', '12', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508207496', '1508207496', '0', '');
INSERT INTO `zc_order` VALUES ('16', 'H121508207496', '12', '2', '14', '24', '0', '0.1167', '2', '8', '0', '1508207496', '1508207496', '0', '');
INSERT INTO `zc_order` VALUES ('17', 'H121508207496', '12', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1508207496', '1508207496', '0', '');
INSERT INTO `zc_order` VALUES ('18', 'H191508207655', '19', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1508207655', '1508207655', '0', '');
INSERT INTO `zc_order` VALUES ('19', 'H171508207740', '17', '2', '14', '24', '77', '0.1167', '0', '1', '0', '1508207740', '1508207925', '1', 'continue_ing,19,X605019420S19,2,48,4,1,24,24,48');
INSERT INTO `zc_order` VALUES ('20', 'H211508212946', '21', '2', '15', '48', '0', '0.1250', '6', '8', '0', '1508212946', '1508212946', '0', '');
INSERT INTO `zc_order` VALUES ('21', 'H211508212954', '21', '2', '13', '48', '0', '0.0417', '2', '8', '0', '1508212954', '1508212954', '0', '');
INSERT INTO `zc_order` VALUES ('22', 'H211508212954', '21', '2', '15', '48', '0', '0.1250', '6', '8', '0', '1508212954', '1508212954', '0', '');
INSERT INTO `zc_order` VALUES ('23', 'H211508212960', '21', '2', '13', '48', '0', '0.0417', '2', '8', '0', '1508212960', '1508212960', '0', '');
INSERT INTO `zc_order` VALUES ('24', 'H171508290477', '17', '2', '14', '24', '0', '0.1167', '2', '8', '0', '1508290477', '1508290477', '0', '');
INSERT INTO `zc_order` VALUES ('25', 'H231509152149', '23', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1509152149', '1509152149', '0', '');
INSERT INTO `zc_order` VALUES ('26', 'X744434623S26', '18', '2', '15', '96', '0', '0.1250', '12', '2', '0', '1509152188', '1509152524', '0', 'continue_ing,26,X744434623S26,3,96,12,1,72,72,96');
INSERT INTO `zc_order` VALUES ('27', 'X621000865S27', '24', '2', '13', '72', '14', '0.0417', '1', '2', '0', '1509152203', '1509283196', '1', 'continue_ing,27,X621000865S27,1,72,1,1,48,34,58');
INSERT INTO `zc_order` VALUES ('28', 'X648756522S28', '23', '2', '13', '48', '48', '0.0417', '0', '1', '0', '1509152228', '1509201685', '1', 'continue_ing,28,X648756522S28,1,48,2,1,24,24,48');
INSERT INTO `zc_order` VALUES ('29', 'H231509152228', '23', '2', '15', '72', '0', '0.1250', '9', '2', '0', '1509152228', '1509152323', '0', '');
INSERT INTO `zc_order` VALUES ('30', 'H181509246275', '18', '2', '13', '24', '0', '0.0417', '1', '3', '0', '1509246275', '1509246287', '0', '');
INSERT INTO `zc_order` VALUES ('31', 'H181509328326', '18', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1509328326', '1509328326', '0', '');
INSERT INTO `zc_order` VALUES ('32', 'H181509328339', '18', '2', '15', '24', '0', '0.1250', '3', '0', '0', '1509328339', '1509328360', '0', '');
INSERT INTO `zc_order` VALUES ('33', 'H191509330301', '19', '2', '13', '24', '0', '0.0417', '1', '8', '0', '1509330301', '1509330301', '0', '');
INSERT INTO `zc_order` VALUES ('34', 'H191509330301', '19', '2', '14', '24', '0', '0.1167', '2', '8', '0', '1509330301', '1509330301', '0', '');
INSERT INTO `zc_order` VALUES ('35', 'H191509330301', '19', '2', '15', '24', '0', '0.1250', '3', '8', '0', '1509330301', '1509330301', '0', '');
INSERT INTO `zc_order` VALUES ('36', 'H161509355218', '16', '2', '13', '24', '0', '0.0417', '1', '0', '0', '1509355218', '1509355233', '0', '');
INSERT INTO `zc_order` VALUES ('37', 'H161509355412', '16', '2', '14', '24', '0', '0.1167', '2', '8', '0', '1509355412', '1509355412', '0', '');
INSERT INTO `zc_order` VALUES ('38', 'H161509355485', '16', '2', '18', '24', '0', '0.0042', '0', '8', '0', '1509355485', '1509355485', '0', '');
INSERT INTO `zc_order` VALUES ('39', 'H161509355502', '16', '2', '18', '24', '0', '0.0042', '0', '8', '0', '1509355502', '1509355502', '0', '');
INSERT INTO `zc_order` VALUES ('40', 'H161509355531', '16', '2', '19', '24', '0', '0.0833', '2', '8', '0', '1509355531', '1509355531', '0', '');
INSERT INTO `zc_order` VALUES ('41', 'H161509355658', '16', '2', '15', '24', '0', '0.1250', '3', '9', '0', '1509355658', '1509355669', '0', '');
INSERT INTO `zc_order` VALUES ('42', 'C161509355688', '16', '2', '13', '72', '0', '0.0417', '3', '0', '0', '1509355688', '1509355688', '0', '');

-- -----------------------------
-- Table structure for `zc_order_back`
-- -----------------------------
DROP TABLE IF EXISTS `zc_order_back`;
CREATE TABLE `zc_order_back` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL COMMENT 'order_hotel::id',
  `reason` text COLLATE utf8_bin NOT NULL COMMENT '原因',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_order_back`
-- -----------------------------
INSERT INTO `zc_order_back` VALUES ('1', '3', '');
INSERT INTO `zc_order_back` VALUES ('2', '2', '');
INSERT INTO `zc_order_back` VALUES ('3', '1', '');
INSERT INTO `zc_order_back` VALUES ('4', '4', '');
INSERT INTO `zc_order_back` VALUES ('5', '5', '');
INSERT INTO `zc_order_back` VALUES ('6', '6', '');
INSERT INTO `zc_order_back` VALUES ('7', '7', '');
INSERT INTO `zc_order_back` VALUES ('8', '8', '');
INSERT INTO `zc_order_back` VALUES ('9', '9', '');

-- -----------------------------
-- Table structure for `zc_order_hotel`
-- -----------------------------
DROP TABLE IF EXISTS `zc_order_hotel`;
CREATE TABLE `zc_order_hotel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `no` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '订单号',
  `userId` int(11) NOT NULL COMMENT 'users::id',
  `orderId` int(11) NOT NULL COMMENT 'order::id',
  `used` int(11) NOT NULL COMMENT '此次入住时长',
  `status` tinyint(2) NOT NULL COMMENT '状态 9已删除 8取消订单 1订单已完成 2入住中 0预约中 3待提现 4已提现',
  `createTime` int(11) NOT NULL,
  `startTime` int(11) NOT NULL,
  `endTime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`orderId`,`no`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_order_hotel`
-- -----------------------------
INSERT INTO `zc_order_hotel` VALUES ('1', 'A191508143584', '19', '1', '25', '1', '1508143584', '1508143921', '1508232880');
INSERT INTO `zc_order_hotel` VALUES ('2', 'A191508143590', '19', '2', '25', '1', '1508143590', '1508143921', '1508232875');
INSERT INTO `zc_order_hotel` VALUES ('3', 'A211508143879', '21', '3', '24', '1', '1508143879', '1508143916', '1508229906');
INSERT INTO `zc_order_hotel` VALUES ('4', 'A171508207891', '17', '19', '77', '1', '1508207891', '1508207925', '1508486537');
INSERT INTO `zc_order_hotel` VALUES ('5', 'A181509152221', '18', '26', '0', '2', '1509152221', '1509152283', '0');
INSERT INTO `zc_order_hotel` VALUES ('6', 'A241509152229', '24', '27', '14', '1', '1509152229', '1509152301', '1509152765');
INSERT INTO `zc_order_hotel` VALUES ('7', 'A231509152273', '23', '29', '0', '2', '1509152273', '1509152323', '0');
INSERT INTO `zc_order_hotel` VALUES ('8', 'A231509152282', '23', '28', '48', '1', '1509152282', '1509152328', '1509324217');
INSERT INTO `zc_order_hotel` VALUES ('9', 'A241509153241', '24', '27', '0', '2', '1509153241', '1509153258', '0');

-- -----------------------------
-- Table structure for `zc_order_money`
-- -----------------------------
DROP TABLE IF EXISTS `zc_order_money`;
CREATE TABLE `zc_order_money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL COMMENT 'order表的订单id',
  `orderNo` varchar(20) COLLATE utf8_bin NOT NULL COMMENT 'order的订单编号',
  `money` float(10,2) NOT NULL COMMENT '订单总金额',
  `type` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'change-表示换房,buy-表示直接购买,continue-续住',
  `add_time` int(11) NOT NULL COMMENT '插入时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_order_money`
-- -----------------------------
INSERT INTO `zc_order_money` VALUES ('1', '1', 'H191508143439', '1.00', 'buy', '1508143455');
INSERT INTO `zc_order_money` VALUES ('2', '2', 'H191508143439', '2.00', 'buy', '1508143455');
INSERT INTO `zc_order_money` VALUES ('3', '3', 'H211508143858', '3.00', 'buy', '1508143865');
INSERT INTO `zc_order_money` VALUES ('4', '12', 'H161508207276', '1.00', 'buy', '1508207291');
INSERT INTO `zc_order_money` VALUES ('5', '19', 'H171508207740', '2.00', 'buy', '1508207752');
INSERT INTO `zc_order_money` VALUES ('6', '26', 'H181509152188', '9.00', 'buy', '1509152211');
INSERT INTO `zc_order_money` VALUES ('7', '27', 'H241509152203', '2.00', 'buy', '1509152212');
INSERT INTO `zc_order_money` VALUES ('8', '28', 'H231509152228', '1.00', 'buy', '1509152239');
INSERT INTO `zc_order_money` VALUES ('9', '29', 'H231509152228', '9.00', 'buy', '1509152239');
INSERT INTO `zc_order_money` VALUES ('10', '26', 'X744434623S26', '3.00', 'continue', '1509152524');
INSERT INTO `zc_order_money` VALUES ('11', '28', 'X648756522S28', '1.00', 'continue', '1509201685');
INSERT INTO `zc_order_money` VALUES ('12', '30', 'H181509246275', '1.00', 'buy', '1509246287');
INSERT INTO `zc_order_money` VALUES ('13', '27', 'X621000865S27', '1.00', 'continue', '1509283196');
INSERT INTO `zc_order_money` VALUES ('14', '32', 'H181509328339', '3.00', 'buy', '1509328360');
INSERT INTO `zc_order_money` VALUES ('15', '36', 'H161509355218', '1.00', 'buy', '1509355233');
INSERT INTO `zc_order_money` VALUES ('16', '41', 'H161509355658', '3.00', 'buy', '1509355669');

-- -----------------------------
-- Table structure for `zc_orderflow`
-- -----------------------------
DROP TABLE IF EXISTS `zc_orderflow`;
CREATE TABLE `zc_orderflow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderhotel_id` int(11) NOT NULL COMMENT 'order_hotel的订单id',
  `hotel` int(11) NOT NULL COMMENT '对应酒店id',
  `orderhotel_time` int(11) NOT NULL COMMENT 'order_hotel订单的创建时间',
  `money` float(10,2) NOT NULL COMMENT '交易金额',
  `orderhotel_used` int(11) NOT NULL COMMENT '在酒店本次所用时间',
  `hotelName` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '酒店名称',
  `roomName` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '房间类型',
  `userName` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '用户姓名',
  `orderhotel_no` varchar(20) COLLATE utf8_bin NOT NULL COMMENT 'order_hotel的订单编号',
  `startTime` int(11) NOT NULL COMMENT '开始入住时间',
  `endTime` int(11) NOT NULL COMMENT '入住结束时间',
  `status` int(3) NOT NULL COMMENT '0-未提现,1-申请中,2-已提现',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_orderflow`
-- -----------------------------
INSERT INTO `zc_orderflow` VALUES ('1', '3', '2', '1508143858', '3.00', '24', '测试酒店', '豪华间', 'joy', 'A211508143879', '1508143916', '1508229906', '0');
INSERT INTO `zc_orderflow` VALUES ('2', '2', '2', '1508143439', '2.00', '25', '测试酒店', '商务间', '哈哈', 'A191508143590', '1508143921', '1508232875', '0');
INSERT INTO `zc_orderflow` VALUES ('3', '1', '2', '1508143439', '1.00', '25', '测试酒店', '标准间', '哈哈', 'A191508143584', '1508143921', '1508232880', '0');
INSERT INTO `zc_orderflow` VALUES ('4', '4', '2', '1508207740', '2.00', '77', '测试酒店', '商务间', '李煦', 'A171508207891', '1508207925', '1508486537', '0');
INSERT INTO `zc_orderflow` VALUES ('5', '6', '2', '1509152203', '0.58', '14', '测试酒店', '标准间', '景小兵', 'A241509152229', '1509152301', '1509152765', '0');
INSERT INTO `zc_orderflow` VALUES ('6', '8', '2', '1509152228', '2.00', '48', '测试酒店', '标准间', '陶友洁', 'A231509152282', '1509152328', '1509324217', '0');

-- -----------------------------
-- Table structure for `zc_perm`
-- -----------------------------
DROP TABLE IF EXISTS `zc_perm`;
CREATE TABLE `zc_perm` (
  `perm_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `perm_type` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '权限名称',
  `perm_url` varchar(30) COLLATE utf8_bin NOT NULL,
  `status` char(1) COLLATE utf8_bin NOT NULL COMMENT '权限的分类 0后台权限 1酒店端权限',
  `perm_parentid` int(11) NOT NULL COMMENT '父级id',
  PRIMARY KEY (`perm_id`),
  KEY `perm_type` (`perm_type`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_perm`
-- -----------------------------
INSERT INTO `zc_perm` VALUES ('1', '首页', 'Index', '0', '0');
INSERT INTO `zc_perm` VALUES ('2', '用户管理', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('3', '酒店管理', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('4', '房间类型', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('5', '财务统计', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('6', '订单管理', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('7', '充值管理', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('8', '扣除管理', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('9', '提现管理', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('10', '权限管理', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('11', '用户列表', 'UserManagement', '0', '2');
INSERT INTO `zc_perm` VALUES ('12', '酒店列表', 'HotelManagement', '0', '3');
INSERT INTO `zc_perm` VALUES ('13', '类型列表', 'RoomType', '0', '4');
INSERT INTO `zc_perm` VALUES ('14', '财务流水', 'Monery', '0', '5');
INSERT INTO `zc_perm` VALUES ('15', '财务明细', 'MoneryDetailed', '0', '5');
INSERT INTO `zc_perm` VALUES ('16', '酒店订单列表', 'Order', '0', '6');
INSERT INTO `zc_perm` VALUES ('49', '平台订单列表', 'Userorder', '0', '6');
INSERT INTO `zc_perm` VALUES ('17', '会员充值', 'Rechange', '0', '7');
INSERT INTO `zc_perm` VALUES ('18', '充值记录', 'RechangeRecord', '0', '7');
INSERT INTO `zc_perm` VALUES ('19', '会员扣除', 'Deduction', '0', '8');
INSERT INTO `zc_perm` VALUES ('20', '扣除记录', 'DeductionRecord', '0', '8');
INSERT INTO `zc_perm` VALUES ('21', '提现处理', 'Postal', '0', '9');
INSERT INTO `zc_perm` VALUES ('22', '提现记录', 'PostalRecord', '0', '9');
INSERT INTO `zc_perm` VALUES ('23', '提现设置', 'PostalSetup', '0', '9');
INSERT INTO `zc_perm` VALUES ('24', '权限组', 'Perm', '0', '10');
INSERT INTO `zc_perm` VALUES ('25', '管理员', 'PermRoot', '0', '10');
INSERT INTO `zc_perm` VALUES ('26', '系统设置', '', '0', '0');
INSERT INTO `zc_perm` VALUES ('27', '备份数据库', 'DB', '0', '26');
INSERT INTO `zc_perm` VALUES ('28', '还原数据库', 'DBReduction', '0', '26');
INSERT INTO `zc_perm` VALUES ('29', '密码修改', 'Pwd', '0', '0');
INSERT INTO `zc_perm` VALUES ('30', '密码修改', 'Pwd', '0', '29');
INSERT INTO `zc_perm` VALUES ('31', '订单管理', '', '1', '0');
INSERT INTO `zc_perm` VALUES ('32', '订单统计', '', '1', '0');
INSERT INTO `zc_perm` VALUES ('33', '财务管理', '', '1', '0');
INSERT INTO `zc_perm` VALUES ('34', '账号管理', '', '1', '0');
INSERT INTO `zc_perm` VALUES ('35', '酒店资料', '', '1', '0');
INSERT INTO `zc_perm` VALUES ('36', '密码修改', '', '1', '0');
INSERT INTO `zc_perm` VALUES ('50', '密码修改', 'Pwd', '1', '36');
INSERT INTO `zc_perm` VALUES ('37', '订单列表', 'OrderList', '1', '31');
INSERT INTO `zc_perm` VALUES ('38', '订单统计', 'OrderCount', '1', '32');
INSERT INTO `zc_perm` VALUES ('39', '财务统计', 'MoneryCount', '1', '33');
INSERT INTO `zc_perm` VALUES ('40', '提现管理', 'Postal', '1', '33');
INSERT INTO `zc_perm` VALUES ('41', '权限设置', 'Perm', '1', '34');
INSERT INTO `zc_perm` VALUES ('42', '增加子账号', 'PermAdd', '1', '34');
INSERT INTO `zc_perm` VALUES ('43', '酒店信息', 'HotelInfo', '1', '35');
INSERT INTO `zc_perm` VALUES ('45', '系统设置', 'SystemSetUp', '0', '26');
INSERT INTO `zc_perm` VALUES ('46', '系统设置', '', '1', '0');
INSERT INTO `zc_perm` VALUES ('47', '系统设置', 'SystemSetUp', '1', '46');
INSERT INTO `zc_perm` VALUES ('48', '系统消息', 'SystemNews', '0', '26');
INSERT INTO `zc_perm` VALUES ('51', '系统消息', 'SystemNews', '1', '46');

-- -----------------------------
-- Table structure for `zc_perm_role`
-- -----------------------------
DROP TABLE IF EXISTS `zc_perm_role`;
CREATE TABLE `zc_perm_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `perm_id` int(11) NOT NULL COMMENT '权限id',
  `role_id` int(11) NOT NULL COMMENT '权限组id',
  PRIMARY KEY (`id`),
  KEY `perm_id` (`perm_id`),
  KEY `role_id` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- -----------------------------
-- Table structure for `zc_postal`
-- -----------------------------
DROP TABLE IF EXISTS `zc_postal`;
CREATE TABLE `zc_postal` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键 唯一标示',
  `number` varchar(220) COLLATE utf8_bin NOT NULL COMMENT '提现记录编号',
  `applydate` int(11) NOT NULL COMMENT '申请日期',
  `passdate` int(11) NOT NULL COMMENT '审核日期',
  `hotel` int(11) NOT NULL COMMENT 'hotel::id',
  `count` int(11) NOT NULL COMMENT '订单数',
  `monery` float(10,2) NOT NULL COMMENT '提现金额',
  `actualmonery` float(10,2) NOT NULL COMMENT '实际提现金额',
  `info` text COLLATE utf8_bin NOT NULL COMMENT '提现说明',
  `return` text COLLATE utf8_bin NOT NULL COMMENT '退回原因',
  `status` tinyint(1) NOT NULL COMMENT '状态 0:正在审核 1:已通过 2:已退回',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_postal`
-- -----------------------------
INSERT INTO `zc_postal` VALUES ('1', 'T21508486738', '1508486738', '1509326383', '2', '4', '8.00', '8.00', '', '', '1');

-- -----------------------------
-- Table structure for `zc_postal_wait`
-- -----------------------------
DROP TABLE IF EXISTS `zc_postal_wait`;
CREATE TABLE `zc_postal_wait` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键 唯一标示',
  `order` int(11) NOT NULL COMMENT 'order::id',
  `amount` int(11) NOT NULL COMMENT '可提现金额',
  `hotel` int(11) NOT NULL COMMENT 'hotel::id',
  `status` int(11) NOT NULL COMMENT '0:待提现 1:已提现 2:提现中',
  `createTime` int(11) NOT NULL COMMENT '写入时间',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_postal_wait`
-- -----------------------------
INSERT INTO `zc_postal_wait` VALUES ('1', '3', '3', '2', '1', '1508229906');
INSERT INTO `zc_postal_wait` VALUES ('2', '2', '2', '2', '1', '1508232875');
INSERT INTO `zc_postal_wait` VALUES ('3', '1', '1', '2', '1', '1508232880');
INSERT INTO `zc_postal_wait` VALUES ('4', '19', '2', '2', '1', '1508486537');
INSERT INTO `zc_postal_wait` VALUES ('5', '27', '2', '2', '0', '1509152765');
INSERT INTO `zc_postal_wait` VALUES ('6', '28', '2', '2', '0', '1509324217');

-- -----------------------------
-- Table structure for `zc_postaldate`
-- -----------------------------
DROP TABLE IF EXISTS `zc_postaldate`;
CREATE TABLE `zc_postaldate` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键 唯一标示',
  `date` int(11) NOT NULL COMMENT '提现日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_postaldate`
-- -----------------------------
INSERT INTO `zc_postaldate` VALUES ('1', '19');
INSERT INTO `zc_postaldate` VALUES ('2', '20');
INSERT INTO `zc_postaldate` VALUES ('3', '21');

-- -----------------------------
-- Table structure for `zc_postalrecord`
-- -----------------------------
DROP TABLE IF EXISTS `zc_postalrecord`;
CREATE TABLE `zc_postalrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键 唯一标示',
  `postal` int(11) NOT NULL COMMENT 'postal::id',
  `order` int(11) NOT NULL COMMENT 'orderflow::id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_postalrecord`
-- -----------------------------
INSERT INTO `zc_postalrecord` VALUES ('1', '1', '1');
INSERT INTO `zc_postalrecord` VALUES ('2', '1', '2');
INSERT INTO `zc_postalrecord` VALUES ('3', '1', '3');
INSERT INTO `zc_postalrecord` VALUES ('4', '1', '4');

-- -----------------------------
-- Table structure for `zc_role`
-- -----------------------------
DROP TABLE IF EXISTS `zc_role`;
CREATE TABLE `zc_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `role_type` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '权限组名称',
  `role_info` varchar(50) COLLATE utf8_bin NOT NULL,
  `hotel` int(11) NOT NULL COMMENT '0后台管理组 hotel::id酒店管理组',
  `role_sta` char(1) COLLATE utf8_bin NOT NULL COMMENT '0正常 1禁用 9删除',
  PRIMARY KEY (`role_id`),
  KEY `role_sta` (`role_sta`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- -----------------------------
-- Table structure for `zc_role_root`
-- -----------------------------
DROP TABLE IF EXISTS `zc_role_root`;
CREATE TABLE `zc_role_root` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `root_id` int(11) NOT NULL COMMENT '人员id',
  `role_id` int(11) NOT NULL COMMENT '权限组id',
  PRIMARY KEY (`id`),
  KEY `root_id` (`root_id`),
  KEY `role_id` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_role_root`
-- -----------------------------
INSERT INTO `zc_role_root` VALUES ('1', '1', '1');

-- -----------------------------
-- Table structure for `zc_rooms`
-- -----------------------------
DROP TABLE IF EXISTS `zc_rooms`;
CREATE TABLE `zc_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roomName` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '房间类型名称',
  `createTime` int(11) NOT NULL COMMENT '新增日期',
  `updateTime` int(11) NOT NULL COMMENT '更新日期',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0正常 1停用 9删除',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_rooms`
-- -----------------------------
INSERT INTO `zc_rooms` VALUES ('1', '标准间', '1504838769', '1504838769', '0');
INSERT INTO `zc_rooms` VALUES ('2', '商务间', '1504838776', '1505783994', '0');
INSERT INTO `zc_rooms` VALUES ('3', '豪华间', '1505783957', '1505783957', '0');
INSERT INTO `zc_rooms` VALUES ('4', '大床房', '1505784892', '1505784892', '0');
INSERT INTO `zc_rooms` VALUES ('5', '单人间', '1505784902', '1505784902', '0');

-- -----------------------------
-- Table structure for `zc_root`
-- -----------------------------
DROP TABLE IF EXISTS `zc_root`;
CREATE TABLE `zc_root` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '用户名',
  `infoname` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '管理员名称',
  `realname` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '真实姓名',
  `number` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '联系方式',
  `pwd` char(32) COLLATE utf8_bin NOT NULL COMMENT '登录密码',
  `status` tinyint(1) NOT NULL COMMENT '0正常 1禁用 9删除',
  `admin` int(11) NOT NULL COMMENT '0超级管理员 root::id子账号',
  PRIMARY KEY (`id`),
  KEY `root` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_root`
-- -----------------------------
INSERT INTO `zc_root` VALUES ('1', 'admin', '总管理员', '卓诚', '12345678910', '21232f297a57a5a743894a0e4a801fc3', '1', '0');

-- -----------------------------
-- Table structure for `zc_root_login`
-- -----------------------------
DROP TABLE IF EXISTS `zc_root_login`;
CREATE TABLE `zc_root_login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `root_id` int(11) NOT NULL COMMENT 'root::id',
  `login_time` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '登录时间',
  `login_ip` varchar(30) COLLATE utf8_bin NOT NULL COMMENT 'IP',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0后台管理登录记录 1酒店管理登录记录',
  PRIMARY KEY (`login_id`),
  KEY `root_id` (`root_id`),
  KEY `login_time` (`login_time`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_root_login`
-- -----------------------------
INSERT INTO `zc_root_login` VALUES ('1', '2', '1508138534', '125.35.135.182', '1');
INSERT INTO `zc_root_login` VALUES ('2', '2', '1508142212', '125.35.135.182', '1');
INSERT INTO `zc_root_login` VALUES ('3', '1', '1508142392', '125.35.135.182', '0');
INSERT INTO `zc_root_login` VALUES ('4', '2', '1508143569', '125.35.135.182', '1');
INSERT INTO `zc_root_login` VALUES ('5', '1', '1508203139', '125.35.135.182', '0');
INSERT INTO `zc_root_login` VALUES ('6', '1', '1508207061', '113.143.80.157', '0');
INSERT INTO `zc_root_login` VALUES ('7', '1', '1508207619', '125.35.135.182', '0');
INSERT INTO `zc_root_login` VALUES ('8', '1', '1508207680', '113.143.80.157', '0');
INSERT INTO `zc_root_login` VALUES ('9', '2', '1508207912', '113.143.80.157', '1');
INSERT INTO `zc_root_login` VALUES ('10', '1', '1508212809', '125.35.135.182', '0');
INSERT INTO `zc_root_login` VALUES ('11', '2', '1508220803', '125.35.135.182', '1');
INSERT INTO `zc_root_login` VALUES ('12', '2', '1508224301', '125.35.135.182', '1');
INSERT INTO `zc_root_login` VALUES ('13', '1', '1508232476', '125.35.135.182', '0');
INSERT INTO `zc_root_login` VALUES ('14', '2', '1508232860', '125.35.135.182', '1');
INSERT INTO `zc_root_login` VALUES ('15', '1', '1508288718', '125.35.135.182', '0');
INSERT INTO `zc_root_login` VALUES ('16', '1', '1508375567', '125.37.173.18', '0');
INSERT INTO `zc_root_login` VALUES ('17', '1', '1508461151', '117.10.161.220', '0');
INSERT INTO `zc_root_login` VALUES ('18', '2', '1508486447', '113.138.145.12', '1');
INSERT INTO `zc_root_login` VALUES ('19', '1', '1508720970', '117.10.161.220', '0');
INSERT INTO `zc_root_login` VALUES ('20', '1', '1508722044', '117.10.161.220', '0');
INSERT INTO `zc_root_login` VALUES ('21', '2', '1508729014', '113.143.93.61', '1');
INSERT INTO `zc_root_login` VALUES ('22', '2', '1508729411', '117.10.161.220', '1');
INSERT INTO `zc_root_login` VALUES ('23', '1', '1508806520', '117.10.161.220', '0');
INSERT INTO `zc_root_login` VALUES ('24', '1', '1508979685', '60.24.170.149', '0');
INSERT INTO `zc_root_login` VALUES ('25', '1', '1508979685', '60.24.170.149', '0');
INSERT INTO `zc_root_login` VALUES ('26', '2', '1509151347', '36.45.194.181', '1');
INSERT INTO `zc_root_login` VALUES ('27', '1', '1509151582', '36.45.194.181', '0');
INSERT INTO `zc_root_login` VALUES ('28', '2', '1509154024', '36.45.194.181', '1');
INSERT INTO `zc_root_login` VALUES ('29', '2', '1509154081', '36.45.194.181', '1');
INSERT INTO `zc_root_login` VALUES ('30', '2', '1509324138', '113.143.95.109', '1');
INSERT INTO `zc_root_login` VALUES ('31', '2', '1509324189', '113.143.95.109', '1');
INSERT INTO `zc_root_login` VALUES ('32', '2', '1509324905', '113.143.95.109', '1');
INSERT INTO `zc_root_login` VALUES ('33', '1', '1509324978', '113.143.95.109', '0');
INSERT INTO `zc_root_login` VALUES ('34', '2', '1509326567', '113.143.95.109', '1');
INSERT INTO `zc_root_login` VALUES ('35', '2', '1509326630', '113.143.95.109', '1');
INSERT INTO `zc_root_login` VALUES ('36', '1', '1509327972', '113.143.95.109', '0');
INSERT INTO `zc_root_login` VALUES ('37', '1', '1509347446', '60.24.170.149', '0');
INSERT INTO `zc_root_login` VALUES ('38', '1', '1509408260', '113.138.155.201', '0');
INSERT INTO `zc_root_login` VALUES ('39', '2', '1509408419', '113.138.155.201', '1');
INSERT INTO `zc_root_login` VALUES ('40', '2', '1509408582', '113.138.155.201', '1');
INSERT INTO `zc_root_login` VALUES ('41', '1', '1509412961', '60.24.170.149', '0');

-- -----------------------------
-- Table structure for `zc_user_orders`
-- -----------------------------
DROP TABLE IF EXISTS `zc_user_orders`;
CREATE TABLE `zc_user_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `no` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '订单号',
  `hotelName` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '酒店名称',
  `roomName` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '房间类型',
  `realname` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '会员姓名',
  `mobile` varchar(12) COLLATE utf8_bin NOT NULL COMMENT '手机号',
  `duration` int(11) NOT NULL COMMENT '购买时长/小时',
  `amount` int(11) NOT NULL COMMENT '总金额',
  `createTime` int(11) NOT NULL COMMENT '添加日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- -----------------------------
-- Table structure for `zc_users`
-- -----------------------------
DROP TABLE IF EXISTS `zc_users`;
CREATE TABLE `zc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键 唯一标示',
  `openid` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '微信端open_id',
  `nickname` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '昵称',
  `realname` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '真实姓名',
  `mobile` varchar(12) COLLATE utf8_bin NOT NULL COMMENT '用户手机号信息',
  `sex` tinyint(1) NOT NULL COMMENT '性别 1男 2女 0未知生物',
  `country` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '国家',
  `province` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '省',
  `city` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '市',
  `headimgid` int(11) NOT NULL COMMENT 'files::id',
  `createTime` int(11) NOT NULL,
  `updateTime` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `openid` (`openid`,`mobile`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `zc_users`
-- -----------------------------
INSERT INTO `zc_users` VALUES ('6', 'oqOMyt3kAFwUlQ84nV1GS6sD5WsY', '非是非非', 'nickehd', '13207513017', '1', '瑞士', '上瓦尔登', '', '5', '1504838858', '1504838858', '0');
INSERT INTO `zc_users` VALUES ('7', 'oqOMyt1ahQChhYclrHW_nV1oROs0', '六年流年留念榴莲', '谷美东', '17694842227', '1', '澳大利亚', '堪培拉', '', '6', '1504849696', '1504849696', '9');
INSERT INTO `zc_users` VALUES ('8', 'oqOMytxpE-QAjEOVWfYx4Fzd2rwQ', '@會痛的石頭@', '胡堂松', '13154030303', '1', '捷克共和国', '', '', '7', '1505288011', '1505288011', '0');
INSERT INTO `zc_users` VALUES ('9', 'oqOMyt_ZQJdB9ISigonKFfb6nvNI', '李煦', '李旭', '15991338080', '1', '中国', '上海', '浦东新区', '8', '1505288011', '1505288011', '0');
INSERT INTO `zc_users` VALUES ('20', 'oEpq1wbZ91OotnpVy9uCd1ITiqS8', '', '李婷', '15009159166', '2', '冰岛', '', '', '29', '1506735054', '1506735054', '0');
INSERT INTO `zc_users` VALUES ('11', 'oqOMyt_pVzgsVLy5s31vHEsYxDaE', '大脑袋', '123', '15022029645', '2', '中国', '天津', '河东', '17', '1505804136', '1505804136', '0');
INSERT INTO `zc_users` VALUES ('12', 'oEpq1wZ77u-BmwY0yYv0fkcnR6i8', '卢锡安', '尹新斌', '18622977554', '1', '中国', '天津', '红桥', '18', '1506478012', '1506478012', '0');
INSERT INTO `zc_users` VALUES ('17', 'oEpq1wXf3-1t8pCba1yJdc1Yzb_0', '李煦', '李煦', '15991338080', '1', '中国', '上海', '浦东新区', '23', '1506639245', '1506639245', '0');
INSERT INTO `zc_users` VALUES ('19', 'oEpq1wQy1fQV3MdO5-uqS-7-12mc', '苦瓜奕`叫半生瓜', '哈哈', '18222905309', '1', '中国', '天津', '南开', '28', '1506648981', '1506648981', '0');
INSERT INTO `zc_users` VALUES ('16', 'oEpq1waJdXeOI8Za05k39IBoUqiE', '六年流年留念榴莲', '谷美东', '17694842227', '1', '澳大利亚', '堪培拉', '', '22', '1506581216', '1506581216', '0');
INSERT INTO `zc_users` VALUES ('18', 'oEpq1wf9C0jIIKtChHyC6eikw8js', '@會痛的石頭@', '胡堂松', '13154030303', '1', '捷克共和国', '', '', '24', '1506646760', '1506646760', '0');
INSERT INTO `zc_users` VALUES ('21', 'oEpq1wej_QBWUpIyLA0G4BtNZw6k', '李启鑫', 'joy', '15102237713', '1', '中国', '天津', '', '32', '1508143670', '1508143670', '0');
INSERT INTO `zc_users` VALUES ('22', 'oEpq1wSfEDGJOhUgGGTskz9i0MEw', '非是非非', '15522909501', '15522909501', '1', '瑞士', '上瓦尔登', '', '33', '1508147724', '1508147724', '0');
INSERT INTO `zc_users` VALUES ('23', 'oEpq1wXRBGWYz7Livij9Gczvh_UI', '怪怪鸡', '陶友洁', '18709157101', '1', '中国', '陕西', '咸阳', '34', '1509151763', '1509151763', '0');
INSERT INTO `zc_users` VALUES ('24', 'oEpq1waDZWwQqViNXk_76SlYwpZk', '景 （技术类）IT  智能家居用品', '景小兵', '18109159325', '1', '中国', '陕西', '安康', '35', '1509151765', '1509151765', '0');
